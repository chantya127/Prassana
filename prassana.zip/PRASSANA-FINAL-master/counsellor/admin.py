# from django.contrib import admin
# from counsellor.models import Data
# # Register your models here.

# admin.site.register(Data)
