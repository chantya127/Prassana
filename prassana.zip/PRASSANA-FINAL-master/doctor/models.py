from django.db import models

# # Create your models here.

class Data(models.Model):
    clinic = models.CharField(max_length=200)
    name = models.CharField(max_length=200)
    mobile = models.CharField(max_length=15)
    email = models.CharField(max_length=200)
    qualification = models.CharField(max_length=200)
    city = models.CharField(max_length=200)
    website = models.CharField(max_length=400)

    def __str__(self):
        return self.name