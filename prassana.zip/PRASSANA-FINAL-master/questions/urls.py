from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.start, name='start'),
    path('pdf1/',views.pdf1, name='pdf1'),
    path('home', views.home, name='home'),
    path('num',views.num,name='num'),
    path('numd',views.numd,name='numd'),
    path('numb',views.numb,name='numb'),
    path('numi',views.numi,name='numi'),
    path('depression/', views.depression, name='depression'),
    path('insomnia/', views.insomnia, name='insomnia'),
    path('binge/', views.binge, name='binge'),
]
