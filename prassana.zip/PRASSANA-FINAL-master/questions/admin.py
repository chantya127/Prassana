from django.contrib import admin

# from .models import Choice,Question,Question_type

# class ChoiceInLine(admin.TabularInline):
#     model=Choice
#     extra=3

# class QuestionAdmin(admin.ModelAdmin):
#     fieldsets = [
#         (None,               {'fields': ['question_text']}),
#         ('Question type', {'fields': ['que_type'],'classes':['collapse']})
#     ]
#     inlines = [ChoiceInLine]
#     list_display = ('question_text' , 'que_type')

# #admin.site.register(Choice)
# admin.site.register(Question, QuestionAdmin)
