from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('pdf/', views.pdf, name='pdf'),
    #path('OTP', views.check, name=check),
    path('questions/<int:id>',views.questions,name='questions'),
    #path('next',views.next,name='next'),
]