from django.shortcuts import render
from django.http import HttpResponse
from django.utils import timezone
from . import models
from django.http import HttpResponseRedirect
#pdf
from django.http import HttpResponse
from django.views.generic import View
from .utils import render_to_pdf #created in step 4
from django.template.loader import get_template
import random 
ans = []
img = []
ans1 = []
img1 = []
def index(request):
    img.clear()
    ans.clear()
    return render(request,'inkblot/inkblot_disp.html')


def questions(request,id):
    data = request.POST.get('information_radio')
    ans.append(data)
    request.session.flush()
    if(id<=10):
        items = models.Question.objects.get(id=id)
        choices = items.choice_set.all()
        images = items.image_set.all()
        for image in images:
            img.append(image)
        a=id-1

        return render(request,'inkblot/index.html',{
        "choices":choices,
        "images":images,
        "id":id+1,
        })
    else:
        del ans[1::2]
        del img[1::2]
        ans.remove(ans[0])
        print("ans : ",ans)
        print("img : ",img)
        global recommend
        recommend = random.randint(51, 81)
        global texts
        #print(type(recommend),recommend)
        if recommend<25:
            texts = "You're well-adjusted. Your personal motto is Find something you love, and do it Unfortunately, your test results indicate you really love sheep."
        elif recommend<50:
            texts = "You're almost well-adjusted. Your personal motto is Hope for the best; prepare for the worst. Based on what we know about you, you're going to need a lot of preparation."
        elif recommend<75:
            texts = "Is a little worriesome. Your personal motto is Colorless green ideas sleep furiously, but no one knows what the hell that means."
        elif recommend<100:
            texts = "Warning!Your personal motto is I am unique, just like everybody else. This makes everyone else happy, because they know there can't be two of you."
        
        context = {
            'result':recommend,
            'texts':texts,
        }
        return render(request,'inkblot/result.html',{'result':recommend,'analysis':texts})


# class GeneratePdf(View):
def pdf( request, *args, **kwargs):
    print("Inside genrate pdf")
    pdf = render_to_pdf('inkblot/invoice.html', {'data': zip(ans, img),'score':recommend,'analysis':texts})
    if pdf:
        response = HttpResponse(pdf, content_type='application/pdf')
        filename = "Inkblot_Test.pdf"
        content = "inline; filename='%s'" %(filename)
        download = request.GET.get("download")
        if download:
            content = "attachment; filename='%s'" %(filename)
        response['Content-Disposition'] = content
        return response
    return HttpResponse("Not found")#/pdf/?download=true
