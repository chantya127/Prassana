from django.apps import AppConfig


class InkblotConfig(AppConfig):
    name = 'inkblot'
