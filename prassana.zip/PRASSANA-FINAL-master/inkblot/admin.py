from django.contrib import admin

from .models import Choice,Question,Image,Option

class ChoiceInline(admin.StackedInline):
    model = Choice
    extra = 3


class ImageInline(admin.StackedInline):
    model = Image

class OptionInline(admin.StackedInline):
    model = Option
    extra = 6

class QuestionAdmin(admin.ModelAdmin):
    fieldsets = [
        (None,               {'fields': ['question_text'],'classes': ['collapse']}),
    ]
    inlines = [ChoiceInline,ImageInline,OptionInline]
admin.site.register(Question, QuestionAdmin)