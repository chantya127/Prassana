from django.apps import AppConfig


class SmartwatchConfig(AppConfig):
    name = 'smartwatch'
