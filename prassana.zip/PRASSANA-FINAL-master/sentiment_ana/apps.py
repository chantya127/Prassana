from django.apps import AppConfig


class SentimentAnaConfig(AppConfig):
    name = 'sentiment_ana'
