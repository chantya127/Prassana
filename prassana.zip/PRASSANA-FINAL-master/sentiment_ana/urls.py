from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.start, name='start'),
    path('pdf/', views.pdf, name="pdf"),
    path('give', views.give, name='give'),
    path('check', views.check, name='check'),
    path('filehandle', views.filehandle, name="filehandle"),
]