from django.shortcuts import render
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from bs4 import BeautifulSoup
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from datetime import datetime
import plotly.graph_objects as go
import plotly.offline as opy
import io
import urllib, base64
import os, sys
from matplotlib import cm
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
import numpy as np
from plotly.subplots import make_subplots 
from matplotlib.patches import Circle, Wedge, Rectangle
from django.utils.translation import gettext
import dateutil.parser as parser
#pdf
from django.http import HttpResponse
from django.views.generic import View
from .utils import render_to_pdf #created in step 4
from django.template.loader import get_template

result_senti=[]
text_senti=[]




def give(request):
    return render(request, 'sentiment_ana/otp.html')

def check(request):
    current_OTP = 1234
    userOTP = int(request.POST['userOTP'])
    if(current_OTP==userOTP):
        return render(request, 'sentiment_ana/steps.html')
    else:
        return render(request, 'sentiment_ana/otp.html')


def degree_range(n): 
    start = np.linspace(0,180,n+1, endpoint=True)[0:-1]
    end = np.linspace(0,180,n+1, endpoint=True)[1::]
    mid_points = start + ((end-start)/2.)
    return np.c_[start, end], mid_points

def rot_text(ang): 
    rotation = np.degrees(np.radians(ang) * np.pi / np.pi - np.radians(90))
    return rotation

def gauge(labels=['LOW','MEDIUM','HIGH','VERY HIGH','EXTREME'], 
          colors='jet_r', arrow=1, title='', fname=True): 
    
    """
    some sanity checks first
    
    """
    
    N = len(labels)
    
    if arrow > N: 
        raise Exception("\n\nThe category ({}) is greated than \
        the length\nof the labels ({})".format(arrow, N))
 
    
    """
    if colors is a string, we assume it's a matplotlib colormap
    and we discretize in N discrete colors 
    """
    
    if isinstance(colors, str):
        cmap = cm.get_cmap(colors, N)
        cmap = cmap(np.arange(N))
        colors = cmap[::-1,:].tolist()
    if isinstance(colors, list): 
        if len(colors) == N:
            colors = colors[::-1]
        else: 
            raise Exception("\n\nnumber of colors {} not equal \
            to number of categories{}\n".format(len(colors), N))

    """
    begins the plotting
    """
    
    fig, ax = plt.subplots()

    ang_range, mid_points = degree_range(N)

    labels = labels[::-1]
    
    """
    plots the sectors and the arcs
    """
    patches = []
    for ang, c in zip(ang_range, colors): 
        # sectors
        patches.append(Wedge((0.,0.), .4, *ang, facecolor='w', lw=2))
        # arcs
        patches.append(Wedge((0.,0.), .4, *ang, width=0.10, facecolor=c, lw=2, alpha=0.5))
    
    [ax.add_patch(p) for p in patches]

    
    """
    set the labels (e.g. 'LOW','MEDIUM',...)
    """

    for mid, lab in zip(mid_points, labels): 

        ax.text(0.35 * np.cos(np.radians(mid)), 0.35 * np.sin(np.radians(mid)), lab, \
            horizontalalignment='center', verticalalignment='center', fontsize=14, \
            fontweight='bold', rotation = rot_text(mid))

    """
    set the bottom banner and the title
    """
    r = Rectangle((-0.4,-0.1),0.8,0.1, facecolor='w', lw=2)
    ax.add_patch(r)
    
    ax.text(0, -0.05, title, horizontalalignment='center', \
         verticalalignment='center', fontsize=22, fontweight='bold')

    """
    plots the arrow now
    """
    
    pos = mid_points[abs(arrow - N)]
    
    ax.arrow(0, 0, 0.225 * np.cos(np.radians(pos)), 0.225 * np.sin(np.radians(pos)), \
                 width=0.04, head_width=0.09, head_length=0.1, fc='k', ec='k')
    
    ax.add_patch(Circle((0, 0), radius=0.02, facecolor='k'))
    ax.add_patch(Circle((0, 0), radius=0.01, facecolor='w', zorder=11))

    """
    removes frame and ticks, and makes axis equal and tight
    """
    
    ax.set_frame_on(False)
    ax.axes.set_xticks([])
    ax.axes.set_yticks([])
    ax.axis('equal')
    plt.tight_layout()
    
    fig = plt.gcf()
    buf = io.BytesIO()
    fig.savefig(buf, format="png")
    buf.seek(0)
    string1 = base64.b64encode(buf.read())
    uri1 = urllib.parse.quote(string1)
    return uri1

# Create your views here.


def start(request):
    return render(request,'sentiment_ana/sentiment_ana_disp.html')



def filehandle(request):
    text_senti.clear()
    result_senti.clear()
    if request.method == 'POST' and request.FILES['myfile']:
        myfile1 = request.FILES['myfile']

        soup = BeautifulSoup(myfile1, "lxml")

        divs = soup.find_all('div',{'class':'_2pin'})
        anchors = soup.find_all('a',{'class':''})

        
        
        for i in range(len(anchors)):
            if(i==0):
                dates = []
                date = anchors[i].string
                dates.append(date)
            else:
                date = anchors[i].string
                dates.append(date)

        # for j in range(len(divs)):
        #     try:
        #         if ('http'or 'https') not in divs[j].text and 'Place' not in divs[j].text and '' != divs[j].text and dates[j] is not None: 
        #             my_dates.append((parser.parse(dates[j].string).year , parser.parse(dates[j].string).month))
        #             mylist.append(divs[j].text)
        #     except:
        #         pass
        
        for j in range(len(divs)):
            if(j==0):
                my_dates=[]
                mylist=[]
                if ('http'or 'https') not in divs[j].text and 'Place' not in divs[j].text and '' != divs[j].text :
                    if(dates[j]!=None):
                        mylist.append(divs[j].text)
                        d = dates[j].string
                        my_dates.append(d)
            elif(j<50):
                if ('http'or 'https') not in divs[j].text and 'Place' not in divs[j].text and '' != divs[j].text :
                    if(dates[j]!=None):
                        mylist.append(divs[j].text)
                        d = dates[j].string
                        my_dates.append(d)
            
        
        values=[]
        pos_val=[]
        neg_val=[]

        mylist = list(mylist)

        sid = SentimentIntensityAnalyzer()
        global neg
        neg=0
        global neu
        neu=0
        global pos
        pos=0
        compound = 0
        no_of_posts=0 
        for data in mylist:
            ss = sid.polarity_scores(data)
            if(ss['pos'] or ss['neg']):
                no_of_posts+=1
            
            neg +=ss['neg']
            neu +=ss['neu']
            pos +=ss['pos']
            
            pos_val.append(ss['pos'])
            neg_val.append(ss['neg'])
            compound +=ss['compound']
            values.append(ss['compound'])
        
        
                
        value = max(neg,pos)
        
        fig1=go.Figure(go.Indicator(
            mode = "gauge+number",
            value = pos,
        #    domain = {'x': [0, 0.45], 'y': [0, 1]},
            title = {'text': "Positive"}))

        fig2=go.Figure(go.Indicator(
            mode = "gauge+number",
            value = neg,
        #    domain = {'x': [0, 0.55], 'y': [0, 1]},
            title = {'text': "Negative"}))

        fig3 = go.Figure(go.Indicator(
            mode = "gauge+number",
            value = neu,
            #domain = {'x': [0, 0.45], 'y': [0, 1]},
            title = {'text': "Neutral"}))

        fig4 = go.Figure(go.Indicator(
            mode = "gauge+number",
            value = compound,
            #domain = {'x': [0, 0.55], 'y': [0, 1]},
            title = {'text': "Compund"}))
        
        
        graph1 = fig1.to_html(full_html=False, default_height=300, default_width=500)
        graph2 = fig2.to_html(full_html=False, default_height=300, default_width=500)
        graph3 = fig3.to_html(full_html=False, default_height=300, default_width=500)
        graph4 = fig4.to_html(full_html=False, default_height=300, default_width=500)
        
        pos_graph = (abs(((pos/no_of_posts)*100) - ((neg/no_of_posts)*100))/20)
        pos_graph = int(pos_graph)

        #plt.style.use('fivethirtyeight')
        
        uri1 = gauge(labels=['LOW','MEDIUM','HIGH','VERY HIGH','EXTREME'], 
            colors='YlOrRd_r', arrow=int(pos_graph), title='Positivity Index : ' + str(pos_graph)+str('/5')) 


        #plt.figure(figsize=(6,7))
        plt.plot(my_dates,values,label="Compound")
        plt.plot(my_dates,pos_val,label="Positive")
        plt.plot(my_dates,neg_val,label="Negatives")
        plt.xticks(rotation=30)
        plt.xlabel("Dates")
        plt.ylabel("Values")
        plt.legend()
        plt.title('Analysis of posts with time')
        neg1 = plt.gcf()
        buf = io.BytesIO()
        neg1.savefig(buf, format="png")
        buf.seek(0)
        string_neg = base64.b64encode(buf.read())
        negg = urllib.parse.quote(string_neg)
        #plt.rcdefaults()
        

        result_senti.append(uri1)
        #result_senti.append(graph1)
        #result_senti.append(graph2)
        #result_senti.append(graph3)
        #result_senti.append(graph4)
        
        text_neg = "As per our Analysis, Your Positivity Index is : " + str(pos_graph)+str('/5') + ". The Negativity in your posts are more which may be a concern.\n We Suggest you to visit a Doctor. If you need any help finding a mental Health Professional visit Doctors section in the website." 
        text_pos = "As per our Analysis, Your Positivity Index is : " + str(pos_graph)+str('/5') + ". The Positivity index is Good.\n So, Keep Posting!!"
        global analysis

        if value==neg:
            text_senti.append(value)
            text_senti.append("Negative")
            analysis = text_neg
            return render(request,'sentiment_ana/res.html',{"result1":"Negative", "value":neg, 'graph1': graph1, 'graph2': graph2, 'graph3': graph3, 'graph4': graph4, 'data':uri1, 'negg':negg, 'analysis':text_neg})
        else:
            text_senti.append(value)
            text_senti.append("Positive")
            analysis = text_pos
            return render(request,'sentiment_ana/res.html',{"result1":"Positive", "value":pos, 'graph1': graph1, 'graph2': graph2, 'graph3': graph3, 'graph4': graph4, 'data':uri1,'negg':negg, 'analysis':text_pos})
        

#pdf
def pdf( request, *args, **kwargs):

    # data = {
    #     'result':text_senti,
    #     'graph':result_senti
    # }
    
    pdf = render_to_pdf('sentiment_ana/invoice.html',{'result':text_senti[1],'analysis':analysis,'graph':result_senti,'pos':int(pos),'neg':int(neg),'neu':int(neu)})
    if pdf:
        response = HttpResponse(pdf, content_type='application/pdf')
        filename = "SocialMedia_Analysis.pdf"
        content = "inline; filename='%s'" %(filename)
        download = request.GET.get("download")
        if download:
            content = "attachment; filename='%s'" %(filename)
        response['Content-Disposition'] = content
        return response
    return HttpResponse("Not found")#/pdf/?download=true

